# WSP-projectTemplate
An initial starting point for WSP students in the creation of their component library. Repository includes basic project folder structure, FPO images, and a CSS reset that will help you throughout the development of your project.
